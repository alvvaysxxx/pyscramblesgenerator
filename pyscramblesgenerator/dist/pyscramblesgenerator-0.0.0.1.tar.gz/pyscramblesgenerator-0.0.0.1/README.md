pyscramblesgenerator.generate_scramble("cube type", N)
"cube type" can be "2x2x2" up to "7x7x7", plus pyraminx, skewb and megaminx
N can be anything that is integer/ Example: 28

So it should look like this: pyscramblesgenerator.generate_scramble("3x3x3", 28)